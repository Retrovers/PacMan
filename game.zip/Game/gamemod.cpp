#include <iostream>
#include <gamemod.h>
#include <string>
#include <map>
#include <gridmanagement.h>

using namespace std;

void About(CLang ParamLang){
    ClearScreen();
    map <string, string> Lang = ParamLang.MapLangString;
    char c;
    while(true){
        cout << Lang["AboutPage"] << endl << Lang["About"] << endl << Lang["HowExitAbout"];
        cin >> c;
        if (c == 'q') break;
    }
}

void MoveToken (CMat & Mat, const char & Move, CPosition & Pos, CMyParam Params)
{
    char car = Mat [Pos.first][Pos.second];
    Mat [Pos.first][Pos.second] = KEmpty;
    if (Move == 'A') {
        -- Pos.first;
        -- Pos.second;
     } else if (Move == Params.MapParamChar["KeyUp"]) {
        --Pos.first;
     } else if (Move == 'E') {
        --Pos.first;
        ++Pos.second;
    } else if (Move == Params.MapParamChar["KeyLeft"]) {
        --Pos.second;
    } else if (Move == Params.MapParamChar["KeyRight"]) {
        ++Pos.second;
    } else if (Move == 'W') {
        ++Pos.first;
        --Pos.second;
    } else if (Move == Params.MapParamChar["KeyDown"]) {
        ++Pos.first;
    } else if (Move == 'C') {
        ++Pos.first;
        ++Pos.second;
    }
    Mat [Pos.first][Pos.second] = car;
} //MoveToken ()

void PlayRandomGameMod(CLang ParamLang, CMyParam Params){
    ClearScreen();
    map <string, string> Lang = ParamLang.MapLangString;
    vector<string> Players(2);
    while (true){
        cout << Lang["RandomGamePage"] << endl << Lang["InstructionForPlayerName"] << endl
                                       << Lang["Player1"] << " : ";
        cin >> Players[0];
        cout << Lang["Player2"] << " : ";
        cin >> Players[1];
        unsigned choise;
        while (true){
            cout << Lang["ConfirmChoise"];
            cin >> choise;
            if (choise == 0 || choise == 1) break;
        }
        if (choise == 1) break;
        ClearScreen();
    }

    ClearScreen();
    cout << Lang["RandomGamePage"] << endl;
    CMat Mat;
    CPosition PosPlayer1, PosPlayer2;
    InitGrid(Mat, Params.MapParamUnsigned["NbRow"], Params.MapParamUnsigned["NbColumn"], PosPlayer1, PosPlayer2, Params);
    DisplayGrid (Mat, Params);
    bool Victory = false;
    const unsigned KSize (10);
    unsigned PartyNum (1);
    const unsigned KMaxPartyNum (KSize * KSize);

    while (PartyNum <= KMaxPartyNum && !Victory)
    {
        cout << Lang["Step"] << " : " << PartyNum << endl;

        Color (Params.MapParamString["ColorP" + to_string((PartyNum%2)+1)]);
        cout << Players[PartyNum%2];
        Color (KColor.find("KReset")->second);
        cout << ", " << Lang["PlayerPlay"] << Lang["EnterMove"] << " : ";

        char Move;
        cin >> Move;

        Move = toupper (Move);
        MoveToken (Mat, Move, (PartyNum%2 == 0 ? PosPlayer1: PosPlayer2), Params);
        ClearScreen();
        cout << Lang["RandomGamePage"] << endl;
        DisplayGrid (Mat, Params);
        if (PosPlayer1 == PosPlayer2) Victory = true;
        ++PartyNum;
    }//while (no victory)

    if (!Victory)
    {
        Color (KColor.find("KMAgenta")->second);
        cout << "Aucun vainqueur" << endl;
    }

    Color (KColor.find("KGreen")->second);
    cout << "Félicitations " << Players[PartyNum%2]
         << " vous avez gagné :)" << endl;
    Color (KColor.find("KReset")->second);

}
void PlayCustomMapMod(CLang ParamLang){
    ClearScreen();
    map <string, string> Lang = ParamLang.MapLangString;

}
