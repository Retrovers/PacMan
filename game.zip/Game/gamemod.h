#ifndef GAMEMOD_H
#define GAMEMOD_H

#include <type.h>

void About(CLang ParamLang);
void PlayRandomGameMod(CLang ParamLang, CMyParam Params);
void PlayCustomMapMod(CLang ParamLang);
void MoveToken (CMat & Mat, const char & Move, CPosition & Pos, CMyParam Params);

#endif // GAMEMOD_H
